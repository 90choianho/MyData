$(function(){
	$(".checkbox a ").click(function(){ //SNS TOGGLE BTN //
		$(".checkbox a").toggleClass("checked");
	});	
});