$(function(){
	$(".checkbox a").click(function(){ //SNS TOGGLE BTN //
		$(this).toggleClass("checked");
	});
	$("#top_btn a").click(function(){ //SNS TOGGLE BTN //
		$(".checkbox a").toggleClass("checked");
		$("#top_btn a").toggleClass("checked");
	});
});
