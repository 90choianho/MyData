$(function(){
	//bx-slider------//
	var slider = $('.bxslider').bxSlider({
  mode: 'horizontal'
});
});
