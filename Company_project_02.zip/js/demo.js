var royal_tab_api = null;

$(document).ready(function() {
    royal_tab_api = new Royal_Tab_Api($('div.royal_tab'));

    var spans = $('div.left_col span');
    spans.click(function() {
        spans.filter('.active').removeClass('active');
        $(this).addClass('active');
    });
});

function setPosition(position, alignment) {
    var element = $('.royal_tab');
    element.removeClass('top bottom left right');
    element.addClass(position + ' ' + alignment);

    Royal_Tab_Data.objects[0]._options.position = position;
    Royal_Tab_Data.objects[0]._options.alignment = alignment;

    if (position === 'top') {
        element.children('div.tabs').insertBefore(element.children('div.views'));
    } else {
        element.children('div.tabs').insertAfter(element.children('div.views'));
    }
}

function setAnimation(animation) {
    var element = $('.royal_tab');
    element.removeClass('fade slide');

    element.addClass(animation);
    Royal_Tab_Data.objects[0]._options.animation = animation;
}

var counter = 1;
function addTab() {
    royal_tab_api.add(0, true, 'New Tab ' + counter, '<h1>New Tab ' + counter + '</h1><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec non dolor sed mauris faucibus placerat non ut mi. Aliquam nibh erat, mattis porta tristique ut, tristique eget risus. Donec suscipit, lorem a fringilla iaculis, mauris arcu posuere dolor, vel euismod mauris purus ac lacus. Nullam eu turpis non mauris iaculis pellentesque. Nam ut justo sed mauris aliquam commodo. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Quisque ornare, leo in venenatis commodo, velit nisl molestie arcu, eu malesuada magna arcu sed diam. Aenean convallis elementum elit, sed vestibulum sapien commodo nec. Sed placerat, nisl in euismod posuere, justo ipsum auctor turpis, eget consequat nisl arcu non leo. Cras enim sem, tincidunt blandit laoreet a, convallis ac nulla.</p><p>Sed ornare, urna id accumsan tincidunt, justo lacus imperdiet nunc, quis lobortis est est eget elit. Suspendisse lacinia feugiat enim, eget tincidunt nulla lobortis pharetra. Quisque id mattis dolor. Nulla massa orci, pulvinar in fermentum ac, commodo nec est. Sed ligula ipsum, malesuada sit amet egestas id, rhoncus posuere velit. Vivamus eget dolor libero, bibendum porta mi. Mauris mattis neque scelerisque massa vestibulum vel consectetur ligula sagittis. Donec vestibulum ornare lacus in commodo. Cras enim purus, eleifend at ultrices at, laoreet in lectus. Vivamus vel mattis sem. Integer sit amet enim risus, in volutpat tortor. Integer consequat nibh ac orci porttitor fringilla. Vivamus placerat elementum imperdiet. Nulla tincidunt, nisi in blandit aliquet, tortor purus tempus lectus, vitae gravida mi sapien et magna.</p>');
    counter++;
}

function setTheme(theme) {
    switch (theme) {
        case 'default':
            $('link').eq(1).attr('href', '../files/css/royal_tab.css');
            break;
        case 'blue':
            $('link').eq(1).attr('href', '../files/css/royal_tab_blue.css');
            break;
        case 'dark':
            $('link').eq(1).attr('href', '../files/css/royal_tab_dark.css');
            break;
        case 'red':
            $('link').eq(1).attr('href', '../files/css/royal_tab_red.css');
            break;
    }

}