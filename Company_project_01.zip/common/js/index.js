$(function(){
	$('#video_slider').bxSlider({
	  mode:'fade',
	  auto: true,
	  autoControls: true,
	  pause: 8000,
	  slideMargin: 20,
		onSliderLoad: function(currentIndex){
		jQuery('#video_slider li video').trigger('play');
		}
	});

	var v = $("#v");
	 //check if video is ready to play
			$(v).on('canplay', function(){
				 $(v).mouseenter(function(){
						$(this).get(0).play();
				 }).mouseleave(function(){
						$(this).get(0).pause();
				 })
			});

		function preloadImages()
 {
	 for(var i = 0; i<arguments.length; i++)
	 {
	 $("<img>").attr("src", arguments[i]);
	 }
 }

 preloadImages("common/images/video_bg.png");

 var videoclip='';
 var player='';

 $(".video_link").hover(function(){
	 videoclip=$(this).attr('href');
	 $(this).attr({"href":"#video_box"});
 },

 function(){
	 $(this).attr({"href":""+videoclip+""});
 });
});
